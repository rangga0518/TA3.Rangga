

<?php $__env->startSection('title', 'Dashboard'); ?>



<?php $__env->startSection('content'); ?>



<link href=" <?php echo e(asset('ela/css/lib/sweetalert/sweetalert.css')); ?>" rel="stylesheet">
<div class="row">
    <div class="col-md-3">
        <div class="card bg-primary p-20">
            <div class="media widget-ten">
                <div class="media-left meida media-middle">
                    <span><i class="ti-bag f-s-40"></i></span>
                </div>
                <div class="media-body media-text-right">
                    <a href="<?php echo e(URL('pelanggan')); ?>"><h2 class="color-white"><?php echo e($dashboard['jumlah_pelanggan']); ?></h2></a>
                    <p class="m-b-0">Jumlah Pelanggan</p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-pink p-20">
            <div class="media widget-ten">
                <div class="media-left meida media-middle">
                    <span><i class="ti-comment f-s-40"></i></span>
                </div>
                <div class="media-body media-text-right">
                    <a href="<?php echo e(URL('pemesanan')); ?>"><h2 class="color-white"><?php echo e($dashboard['jumlah_pesanan']); ?></h2></a>
                    <p class="m-b-0">Jumlah Pesanan</p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-success p-20">
            <div class="media widget-ten">
                <div class="media-left meida media-middle">
                    <span><i class="ti-vector f-s-40"></i></span>
                </div>
                <div class="media-body media-text-right">
                    <a href="<?php echo e(URL('reservasi')); ?>"><h2 class="color-white"><?php echo e($dashboard['jumlah_reservasi']); ?></h2></a>
                    <p class="m-b-0">Jumlah Reservasi</p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-danger p-20">
            <div class="media widget-ten">
                <div class="media-left meida media-middle">
                    <span><i class="ti-location-pin f-s-40"></i></span>
                </div>
                <div class="media-body media-text-right">
                    <a href="<?php echo e(URL('pegawai/hidangan')); ?>"><h2 class="color-white"><?php echo e($dashboard['jumlah_hidangan']); ?></h2></a>
                    <p class="m-b-0">Jumlah Hidangan</p>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">

    <div class="col-lg-6">
        <div class="card">
            <div class="card-title">
                <h4>Reservasi</h4>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Pelanggan</th>
                                <th>Pegawai</th>
                                <th>Tanggal Reservasi</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        
                    </table>
                </div>
                <a href="" class="btn btn-primary">Selengkapnya</a>
            </div>
        </div>
    </div>

	<div class="col-lg-6">
	    <div class="card">
	        <div class="card-title">
	            <h4>Recent Orders </h4>
	        </div>
	        <div class="card-body">
	            <div class="table-responsive">
	                <table class="table">
	                    <thead>
	                        <tr>
	                            <th>Pelanggan</th>
	                            <th>Pegawai</th>
	                            <th>Tanggal Pesan</th>
	                            <th>Status</th>
                                <th>Aksi</th>
	                        </tr>
	                    </thead>
	                    
	                </table>
	            </div>
                <a href="" class="btn btn-primary">Selengkapnya</a>
	        </div>
	    </div>
	</div>
</div>

<script src="<?php echo e(asset('ela/js/lib/sweetalert/sweetalert.min.js')); ?>"></script>
<!-- scripit init-->
<script type="text/javascript">
    swal("Hey", "Selamat datang di dashboard Dream Restaurant", "success")
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pegawai', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA3.New\resources\views/pegawai/index.blade.php ENDPATH**/ ?>