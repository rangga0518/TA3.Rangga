

<?php $__env->startSection('title', 'Buat Reservasi'); ?>



<?php $__env->startSection('content'); ?>
                <div class="col-lg-8">
                    <div class="card" style="background: #f5f5f5">
                            <div class="basic-form">
                                <form method="POST" action="<?php echo e(URL('reservasi')); ?>">
                                    <?php echo e(csrf_field()); ?>



                                    <div class="form-group row">
                                        <label for="" class="col-sm-2 col-form-label">Restoran</label>
                                        <div class="col-sm-10">
                                            <select name="id_restoran" class="form-control">
                                                
                                            </select>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="" class="col-sm-2 col-form-label">Nama Pelanggan</label>
                                        <div class="col-sm-10">
                                            <select name="id_pelanggan" class="form-control">
                                                
                                            </select>
                                        </div>
                                    </div>


                                    <div class="form-group row">
                                        <label for="" class="col-sm-2 col-form-label">Nama Pegawai</label>
                                        <div class="col-sm-10">
                                            <select name="id_pegawai" class="form-control">
                                                
                                            </select>
                                        </div>
                                    </div>


                                    <div class="form-group row">
                                        <label for="no_meja_reservasi" class="col-sm-2 col-form-label">Nomor Meja</label>
                                        <div class="col-sm-10">
                                            <input type="text" class="form-control" id="no_meja_reservasi" name="no_meja_reservasi">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="status_reservasi" class="col-sm-2 col-form-label">Status</label>
                                        <div class="col-sm-10">
                                            <select name="status_reservasi" class="form-control">
                                                <option value="Batal">Batal</option>
                                                <option value="Dikonfirmasi">Dikonfirmasi</option>
                                                <option value="Menunggu Konfirmasi">Menunggu Konfirmasi</option>
                                                <option value="Sedang Berlangsung">Sedang Berlangsung</option>
                                                <option value="Selesai">Selesai</option>
                                            </select>
                                        </div>
                                    </div>

                                    <div style="text-align: right;">
                                        <button type="submit" class="btn btn-primary">Lanjutkan</button>
                                        <a class="btn btn-danger" href="<?php echo e(URL('reservasi')); ?>">Batal</a>
                                    </div>
                                </form>
                            </div>
                    </div>
                </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pegawai', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA3.New\resources\views/pegawai/reservasi/create.blade.php ENDPATH**/ ?>