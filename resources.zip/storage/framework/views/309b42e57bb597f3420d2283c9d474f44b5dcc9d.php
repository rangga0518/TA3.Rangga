
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Ini Halaman pelanggan</h1>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.pelanggan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA3.New\resources\views/pelanggan/restoran.blade.php ENDPATH**/ ?>