

<?php $__env->startSection('title', 'Hidangan'); ?>



<?php $__env->startSection('content'); ?>
<link href=" <?php echo e(asset('ela/css/lib/sweetalert/sweetalert.css')); ?>" rel="stylesheet">
        <a href="<?php echo e(URL('hidangan/create')); ?>" class="btn btn-success">Tambah Hidangan</a>

        <div class="card">
                    <div class="card-body">
                        <ul class="nav nav-tabs customtab" role="tablist">
                            <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#makanan" role="tab"><span class="hidden-sm-up"><i class="ti-home"></i></span> <span class="hidden-xs-down">Makanan</span></a> </li>
                            <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#minuman" role="tab"><span class="hidden-sm-up"><i class="ti-user"></i></span> <span class="hidden-xs-down">Minuman</span></a> </li>
                        </ul>
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div class="tab-pane active" id="makanan" role="tabpanel">
                                <div class="row">
                                
                                </div>
                            </div>
                            <div class="tab-pane" id="minuman" role="tabpanel">
                                <div class="row">
                                
                                </div>
                            </div>
                        </div>
                    </div>
                </div>



                <script src="<?php echo e(asset('ela/js/lib/sweetalert/sweetalert.min.js')); ?>"></script>
                <!-- scripit init-->
                <script type="text/javascript">
                    $('form').submit(function(e){
                        var form = this;
                        e.preventDefault();
                        swal({
                                title: "Yakin Menghapus Hidangan?",
                                text: "Hidangan yang dihapus tidak bisa dikembalikan lhoo.",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#DD6B55",
                                confirmButtonText: "Yes, delete it !!",
                                closeOnConfirm: false
                            },
                            function(){
                                form.submit();
                            }
                        );
                    });

                </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pegawai', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA3.New\resources\views/pegawai/hidangan/index.blade.php ENDPATH**/ ?>