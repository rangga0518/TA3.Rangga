

<?php $__env->startSection('title', 'Buat Reservasi'); ?>



<?php $__env->startSection('content'); ?>
                    

                    <div class="col-lg-6">
                        <div class="card" style="background: #f5f5f5">
                                <div class="basic-form">
                                    <form method="POST" action="<?php echo e(URL('reservasi')); ?>">
                                        <?php echo e(csrf_field()); ?>


                                        <div class="form-group">
                                            <label for="nama">Nama</label>
                                            
                                        </div>

                                        <div class="form-group">
                                            <label for="email">Email</label>
                                            
                                        </div>
                                        <div class="form-group">
                                            <label for="id_restoran">Restoran</label>
                                            <select name="id_restoran" class="form-control">
                                                
                                            </select>
                                        </div>
                                        <div style="text-align: right;">
                                            <button type="submit" class="btn btn-primary">Lanjutkan</button>
                                            <a class="btn btn-danger" href="<?php echo e(URL('reservasi')); ?>">Batal</a>
                                        </div>
                                    </form>
                                </div>
                        </div>
                    </div>
                    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pelanggan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA3.New\resources\views/pelanggan/reservasi/create.blade.php ENDPATH**/ ?>