

<?php $__env->startSection('title', 'Buat Pemesanan'); ?>



<?php $__env->startSection('content'); ?>

                    <div class="card">
                            <div class="basic-form">
                                 <form method="POST" action="<?php echo e(URL('pemesanan/')); ?>">
                                    <?php echo e(csrf_field()); ?>


                                    <div class="form-group">
                                        <label for="id_restoran">Restoran</label>
                                        <select name="id_restoran" class="form-control">
                                            
                                        </select>
                                    </div>


                                    <ul class="nav nav-tabs customtab" role="tablist">
                                        <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#makanan" role="tab"><span class="hidden-sm-up"><i class="ti-fire"></i></span> <span class="hidden-xs-down">Makanan</span></a> </li>
                                        <li class="nav-item"> <a class="nav-link" data-toggle="tab" href="#minuman" role="tab"><span class="hidden-sm-up"><i class="ti-fire"></i></span> <span class="hidden-xs-down">Minuman</span></a> </li>
                                    </ul>
                                    <!-- Tab panes -->
                                    <div class="tab-content">
                                        <div class="tab-pane active" id="makanan" role="tabpanel">
                                            <div class="row">
                                            
                                            </div>
                                        </div>
                                        <div class="tab-pane" id="minuman" role="tabpanel">
                                            <div class="row">
                                            
                                            </div>
                                        </div>
                                        
                                        <div style="text-align: right;">
                                            <button type="submit" class="btn btn-primary">Submit</button>
                                            <a class="btn btn-danger" href="<?php echo e(URL('pemesanan')); ?>">Batal</a>
                                        </div>
                                    </div>                                    
                                </form>
                            </div>
                    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.pegawai', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\TA3.New\resources\views/pegawai/pemesanan/create.blade.php ENDPATH**/ ?>